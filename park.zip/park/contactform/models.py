from django.db import models

# Create your models here.
class ContactUs(models.Model):
    yourname=models.CharField(max_length=150)
    youremail=models.CharField(max_length=150)
    yourphone=models.CharField(max_length=150)
    yourproject=models.CharField(max_length=150)
    subject=models.CharField(max_length=150)
    message=models.CharField(max_length=150)