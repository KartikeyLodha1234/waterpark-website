from django.contrib import admin

# Register your models here.
from contactform.models import ContactUs
class ContactAdmin(admin.ModelAdmin):
    list_display=('yourname','youremail','yourphone','yourproject','subject','message')

admin.site.register(ContactUs,ContactAdmin)