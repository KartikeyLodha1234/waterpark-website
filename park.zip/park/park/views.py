from django.http import HttpResponse
from django.shortcuts import render
from Service.models import Box
from Ourservice.models import Service
from OurTeam.models import Team
from contactform.models import ContactUs
from django.core.mail import send_mail
from itsblog.models import Customer, Booking
from django.core.mail import EmailMessage
from django.template.loader import render_to_string


def homepage (request):
    
    BoxData=Box.objects.all()
    service=Service.objects.all()
    team=Team.objects.all()

    data={
        'boxData':BoxData,
        'service':service,
        'team':team
    }
    return render(request, 'index.html',data)
def aboutpage (request):
    return render(request, 'about.html')

def blog(request):
    customer = Customer.objects.get(name="Kartikey Lodha")
    booking = customer.bookings.all()
    return render (request,'blog.html',{'customer':customer, 'booking':booking})

def team(request):
    return render (request,"team.html")

def page(request):
    return render (request,"page.html")

def attraction(request):
    return render (request,"attraction.html")

def feature(request):
    return render (request,"feature.html")

def gallery(request):
    return render (request,"gallery.html")

def package(request):
    return render (request,"package.html")


def service(request):
    return render (request,"service.html")

def testimonial(request):
    return render (request,"testimonial.html")

def email(request):
    return render (request,"email.html")

def contact(request):
    subject = 'Test Email with HTML Template'
    from_email = 'kartikeylodha567@gmail.com'
    recipient_list = ['kartikeylodha456@gmail.com']
    # Render the HTML template with context
    context = {'username': 'Kartikey Lodha'} # Pass dynamic data to the template
    html_content = render_to_string('email.html', context)
     # Create the email
    email = EmailMessage(subject, html_content, from_email, recipient_list)
    email.content_subtype = 'html' # Specify content type as HTML
     # Send the email
    email.send()

    send_mail(
    "Test Email",
    "This is a test email ",
    "kartikeylodha567@gmail.com",
    ["kartikeylodha456@gmail.com"],
    )

    msg=''
    if request.method=='POST':
        yourname=request.POST.get('yourname')
        youremail=request.POST.get('youremail')
        yourphone=request.POST.get('yourphone')
        yourproject=request.POST.get('yourproject')
        subject=request.POST.get('subject')
        message=request.POST.get('message')
        alldata=ContactUs(yourname=yourname,youremail=youremail,yourphone=yourphone,yourproject=yourproject,subject=subject,message=message)
        alldata.save()
        msg="Form submitted"
    return render(request,'contact.html',{'msg':msg})
