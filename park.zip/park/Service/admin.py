from django.contrib import admin

# Register your models here.
from Service.models import Box
class BoxAdmin(admin.ModelAdmin):
  list_display=('box_title', 'box_desc','box_icon')
  
admin.site.register(Box,BoxAdmin)