from django.db import models

# Create your models here.
class Box(models.Model):    
    box_title=models.TextField()
    box_desc=models.CharField(max_length=150)
    box_icon=models.FileField(upload_to="media", max_length=250, null=True, default=None)