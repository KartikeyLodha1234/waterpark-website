from django.contrib import admin
from itsblog.models import Customer, Booking

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email')

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('waterpark_name', 'booking_date', 'customer', 'number_of_people')
