from django.db import models

class Customer(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.name


class Booking(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="bookings")
    waterpark_name = models.CharField(max_length=255)
    booking_date = models.DateField()
    number_of_people = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.waterpark_name} on {self.booking_date} for {self.customer.name}"
