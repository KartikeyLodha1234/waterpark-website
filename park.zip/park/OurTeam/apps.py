from django.apps import AppConfig


class OurteamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'OurTeam'
