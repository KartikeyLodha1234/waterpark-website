from django.db import models

# Create your models here.
class Team(models.Model):
    team_title=models.CharField(max_length=150)
    team_designation=models.CharField(max_length=150)
    team_desc=models.TextField()
    team_img=models.FileField(upload_to="media", max_length=250, null=True, default=None)