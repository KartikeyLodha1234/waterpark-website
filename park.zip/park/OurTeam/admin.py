from django.contrib import admin

# Register your models here.
from OurTeam.models import Team
class TeamAdmin(admin.ModelAdmin):
    list_display=('team_title', 'team_designation', 'team_desc', 'team_img')

admin.site.register(Team,TeamAdmin)