from django.contrib import admin

# Register your models here.
from Ourservice.models import Service
class OurserviceAdmin(admin.ModelAdmin):
    list_display=('Ourservice_img', 'Ourservice_title','Ourservice_desc')

admin.site.register(Service,OurserviceAdmin)