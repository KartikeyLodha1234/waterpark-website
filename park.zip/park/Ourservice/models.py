from django.db import models

# Create your models here.
class Service(models.Model):
    Ourservice_img=models.CharField(max_length=150)
    Ourservice_title=models.TextField()
    Ourservice_desc=models.CharField(max_length=150)